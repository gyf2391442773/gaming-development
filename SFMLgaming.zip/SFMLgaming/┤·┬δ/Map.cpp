#include "stdafx.h"
#include "Map.h"

Map::Map()
{
	//p
}

Map::~Map()
{
}

void Map::update()
{
}

void Map::render()
{
}
